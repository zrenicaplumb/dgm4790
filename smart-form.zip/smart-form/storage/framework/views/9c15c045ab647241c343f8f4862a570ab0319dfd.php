<!DOCTYPE html>
<html>
<head>
	<title>Massively by HTML5 UP</title>
	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
	
	<noscript><link rel="stylesheet" href="assets/css/noscript.css" /></noscript>
	<link rel="stylesheet" href="public/css/main.css" />
	<link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('css/main.css')); ?>">
</head>
<body class="is-loading">
	<div id="wrapper" class="fade-in">
		
			<?php echo $__env->yieldContent('intro'); ?>
		

<!-- Header -->
		<header id="header">
			<a href="index.html" class="logo">Massively</a>
		</header>

	<!-- Nav -->
		<nav id="nav">
			<ul class="links">
				<?php echo $__env->yieldContent('links'); ?>
			</ul>
			<ul class="icons">
				<li><a href="#" class="icon fa-twitter"><span class="label">Twitter</span></a></li>
				<li><a href="#" class="icon fa-facebook"><span class="label">Facebook</span></a></li>
				<li><a href="#" class="icon fa-instagram"><span class="label">Instagram</span></a></li>
				<li><a href="#" class="icon fa-github"><span class="label">GitHub</span></a></li>
			</ul>
		</nav>
		<div id="main">
			<?php echo $__env->yieldContent('content'); ?>
		</div>
		<!-- Footer -->
					<footer id="footer">
						<section>
							<form method="POST" action="/">
								<?php echo e(csrf_field()); ?>

								<div class="field">
									<label for="name">Name</label>
									<input type="text" name="name" id="name" />
								</div>
								<div class="field">
									<label for="email">Email</label>
									<input type="text" name="email" id="email" />
								</div>
								<div class="field">
									<label for="message">Message</label>
									<textarea name="message" id="message" rows="3"></textarea>
									<!-- <input name="_token" type="hidden" value="<?php echo e(csrf_token()); ?>"/> -->
								</div>
								<ul class="actions">
									<li><input type="submit" value="Send Message" name="submit" /></li>
								</ul>
							</form>
						</section>
						<section class="split contact">
							<section class="alt">
								<h3>Address</h3>
								<p>1234 Somewhere Road #87257<br />
								Nashville, TN 00000-0000</p>
							</section>
							<section>
								<h3>Phone</h3>
								<p><a href="#">(000) 000-0000</a></p>
							</section>
							<section>
								<h3>Email</h3>
								<p><a href="#">info@untitled.tld</a></p>
							</section>
							<section>
								<h3>Social</h3>
								<ul class="icons alt">
									<li><a href="#" class="icon alt fa-twitter"><span class="label">Twitter</span></a></li>
									<li><a href="#" class="icon alt fa-facebook"><span class="label">Facebook</span></a></li>
									<li><a href="#" class="icon alt fa-instagram"><span class="label">Instagram</span></a></li>
									<li><a href="#" class="icon alt fa-github"><span class="label">GitHub</span></a></li>
								</ul>
							</section>
						</section>
					</footer>

				<!-- Copyright -->
					<div id="copyright">
						<ul><li>&copy; Untitled</li><li>Design: <a href="https://html5up.net">HTML5 UP</a></li></ul>
					</div>

			</div>

	<!-- Scripts -->
			<script type="text/javascript" src="<?php echo e(URL::asset('js/jquery.min.js')); ?>"></script>
			<script type="text/javascript" src="<?php echo e(URL::asset('js/jquery.scrollex.min.js')); ?>"></script>
			<script type="text/javascript" src="<?php echo e(URL::asset('js/jquery.scrolly.min.js')); ?>"></script>
			<script type="text/javascript" src="<?php echo e(URL::asset('js/skel.min.js')); ?>"></script>
			<script type="text/javascript" src="<?php echo e(URL::asset('js/util.js')); ?>"></script>
			<script type="text/javascript" src="<?php echo e(URL::asset('js/main.js')); ?>"></script>



</body>
</html>