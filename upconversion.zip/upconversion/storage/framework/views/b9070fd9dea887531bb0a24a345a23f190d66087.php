<?php $__env->startSection('header'); ?>
	<title>Editorial by HTML5 UP</title>
			<meta charset="utf-8" />
			<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
			<!--[if lte IE 8]><script src="assets/js/ie/html5shiv.js"></script><![endif]-->
			<link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet" type="text/css" >
			<link href="<?php echo e(asset('css/font-awesome.min.css')); ?>" rel="stylesheet" type="text/css" >
			<link href="<?php echo e(asset('css/ie8.css')); ?>" rel="stylesheet" type="text/css" >
			<link href="<?php echo e(asset('css/ie9.css')); ?>" rel="stylesheet" type="text/css" >
			<link href="<?php echo e(asset('css/main.css')); ?>" rel="stylesheet" type="text/css" >
			


			<!--[if lte IE 9]><link rel="stylesheet" href="assets/css/ie9.css" /><![endif]-->
			<!--[if lte IE 8]><link rel="stylesheet" href="assets/css/ie8.css" /><![endif]-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>