

<!DOCTYPE HTML>
	<!--
		Editorial by HTML5 UP
		html5up.net | @ajlkn
		Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
	-->
	<html>
		<head>
			
			
			<?php echo $__env->make('pages.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

		</head>
	<body>

		<!-- Wrapper -->
			<div id="wrapper">

				<!-- Main -->
					<div id="main">
						<?php echo $__env->yieldContent('indexcontent'); ?>
					</div>

					<!-- Sidebar -->
					<div id="sidebar">
						<?php echo $__env->yieldContent('sidebar'); ?>
					</div>

			</div>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<!--[if lte IE 8]><script src="assets/js/ie/respond.min.js"></script><![endif]-->
			<script src="assets/js/main.js"></script>

	</body>
</html>				