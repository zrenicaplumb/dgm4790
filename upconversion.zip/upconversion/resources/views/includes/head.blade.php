<title>Editorial by HTML5 UP</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<!--[if lte IE 8]><script src="assets/js/ie/html5shiv.js"></script><![endif]-->
		<link rel="stylesheet" href="assets/css/main.css" />
		<!--[if lte IE 9]><link rel="stylesheet" href="assets/css/ie9.css" /><![endif]-->
		<!--[if lte IE 8]><link rel="stylesheet" href="assets/css/ie8.css" /><![endif]-->
		<link href="{{ asset('css/app.css') }}" rel="stylesheet" type="text/css" >
		<link href="{{ asset('css/main.css') }}" rel="stylesheet" type="text/css" >
		<link href="{{ asset('images/') }}" rel="stylesheet" type="text/css" >
		<script type="text/javascript" src="{{ asset('js/custom.js') }}"></script>
		<script type="text/javascript" src="{{ asset('js/jquery.min.js') }}"></script>
		<script type="text/javascript" src="{{ asset('js/main.js') }}"></script>
		<script type="text/javascript" src="{{ asset('js/skel.js') }}"></script>
		<script type="text/javascript" src="{{ asset('js/util.js') }}"></script>
		<!-- <script type="text/javascript" src="{!! asset('js/app.min.js') !!}"></script> -->

