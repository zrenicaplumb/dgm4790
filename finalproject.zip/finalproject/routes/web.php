<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('signup', 'userController@getSignup');
Route::post('signup', 'userController@postSignup');
Route::get('signin', 'userController@getSignin');
Route::post('signin', 'userController@postSignin');
Route::get('hello', 'userController@getHello');
Route::get('profile', 'userController@getProfile');
Route::get('logout', 'userController@getLogout');
Route::get('/', 'masterController@products');
Route::get('thanks', 'masterController@thanks');
Route::get('checkout', 'masterController@checkout');
Route::get('checkout/{id}','masterController@addToCart');

 