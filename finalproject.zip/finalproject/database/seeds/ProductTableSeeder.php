<?php

use Illuminate\Database\Seeder;
use App\Product;

class ProductTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $product = new Product([
        	'imagePath' => 'https://images.nike.com/is/image/DotCom/PDP_HERO_M/863766_001_A_PREM/air-zoom-vomero-12-womens-running-shoe.jpg',
        	'title' => 'Nike',
        	'price' => 120,
        	'description' => 'Curabitur non nulla sit amet nisl tempus convallis quis ac lectus. Praesent sapien massa, convallis a pellentesque nec, egestas non nisi. Mauris blandit aliquet elit, eget tincidunt nibh pulvinar a. Donec sollicitudin molestie malesuada.'
        ]);
        $product->save();

        $product = new Product([
        	'imagePath' => 'https://i.pinimg.com/originals/f2/de/10/f2de103a374439d454f2a01eed12239d.jpg',
        	'title' => 'Adidas',
        	'price' => 90,
        	'description' => 'Curabitur non nulla sit amet nisl tempus convallis quis ac lectus. Praesent sapien massa, convallis a pellentesque nec, egestas non nisi. Mauris blandit aliquet elit, eget tincidunt nibh pulvinar a. Donec sollicitudin molestie malesuada.'
        ]);
        $product->save();

        $product = new Product([
        	'imagePath' => 'https://images.nike.com/is/image/DotCom/PDP_HERO_M/AA1253_002_A_PREM/air-jordan-xxxii-mens-basketball-shoe.jpg',
        	'title' => 'Jordan',
        	'price' => 666,
        	'description' => 'Curabitur non nulla sit amet nisl tempus convallis quis ac lectus. Praesent sapien massa, convallis a pellentesque nec, egestas non nisi. Mauris blandit aliquet elit, eget tincidunt nibh pulvinar a. Donec sollicitudin molestie malesuada.'
        ]);
        $product->save();
    }
}
