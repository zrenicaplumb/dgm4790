<?php $__env->startSection('title'); ?>
	Products
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
	<div class="container">
		<?php $__currentLoopData = $products->chunk(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productChunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="row row-margin">
				<?php $__currentLoopData = $productChunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="col-xs-12 col-sm-6 col-md-4">
						<div class="img-wrap">
							<a href="#"><img src="<?php echo e($product->imagepath); ?>"></a> 
							<p class="title"><?php echo e($product->title); ?></p>
							<p class="price">$<?php echo e($product->price); ?></p>
							<p class="description"><?php echo e($product->description); ?></p>
							<a href="checkout" class="btn btn-primary" role="button" >Add to Cart</a>
						</div>
					</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>