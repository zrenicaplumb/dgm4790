<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row">
		<div class="col-md-4 margin-auto">
			<div class="form-wrap">
				
				<?php if(count($errors) > 0): ?>
					<div class="alert alert-danger">
						<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<p><?php echo e($error); ?></p>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
				<?php endif; ?>
				<form method="POST" action="signin">
					<h1>Sign in</h1>
					<fieldset>
						<label for="name">Name</label>
						<input type="text" name="name" class="form-control">
					</fieldset>
					<fieldset>
						<label for="email">Email</label>
						<input type="email" name="email" class="form-control">
					</fieldset>
					<fieldset>
						<label for="password">Password</label>
						<input type="password" name="password" class="form-control">
					</fieldset>
					<button type="submit" name="submit" class="">Signin</button>
					<?php echo e(csrf_field()); ?>

				</form>
			</div>
		</div>
	</div>
</div>
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>