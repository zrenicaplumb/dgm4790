@extends('layouts.default')
@section('content')
<div class="container">
		<h1>Thank you!</h1>
</div>

@endsection