@extends('layouts.default')
@section('content')
<div class="container">
	<div class="row">
		<div class="col-md-4 margin-auto">
			<div class="form-wrap">
				
				@if(count($errors) > 0)
					<div class="alert alert-danger">
						@foreach($errors->all() as $error)
							<p>{{ $error }}</p>
						@endforeach
					</div>
				@endif
				<form method="POST" action="signin">
					<h1>Sign in</h1>
					<fieldset>
						<label for="name">Name</label>
						<input type="text" name="name" class="form-control">
					</fieldset>
					<fieldset>
						<label for="email">Email</label>
						<input type="email" name="email" class="form-control">
					</fieldset>
					<fieldset>
						<label for="password">Password</label>
						<input type="password" name="password" class="form-control">
					</fieldset>
					<button type="submit" name="submit" class="">Signin</button>
					{{ csrf_field() }}
				</form>
			</div>
		</div>
	</div>
</div>
	
@endsection