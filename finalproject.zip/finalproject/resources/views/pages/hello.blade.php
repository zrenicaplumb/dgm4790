@extends('layouts.default')
@section('content')
<div class="container">
		<h1>Hello Customer!</h1>
</div>

@endsection