@extends('layouts.default')
@section('title')
	Products
@endsection
@section('content')
	<div class="container">
		@foreach($products->chunk(3) as $productChunk)
			<div class="row row-margin">
				@foreach($productChunk as $product)
					<div class="col-xs-12 col-sm-6 col-md-4">
						<div class="img-wrap">
							<a href="#"><img src="{{$product->imagepath}}"></a> 
							<p class="title">{{$product->title}}</p>
							<p class="price">${{$product->price}}</p>
							<p class="description">{{$product->description}}</p>
							<a href="checkout" class="btn btn-primary" role="button" >Add to Cart</a>
						</div>
					</div>
				@endforeach
			</div>
		@endforeach
	</div>
@endsection