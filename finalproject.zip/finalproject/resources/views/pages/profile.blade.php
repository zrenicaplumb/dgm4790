@extends('layouts.default')
@section('content')
<div class="container">
	<div class="col-xs-12">
		<h1>User Profile</h1>
	</div>
</div>
@endsection