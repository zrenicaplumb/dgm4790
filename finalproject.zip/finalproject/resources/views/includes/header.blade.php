
<div class="container">
	<a href=""><img src="{{asset('img/logo.png')}}" class="logo"></a>
	<nav>
		<ul>
			<li><a href="/">Products</a></li>
			<li><a href="checkout">Checkout</a></li>
			<li><a href="thanks">Thank you</a></li>
			<li><a href="signup">Registration</a></li>
			<li><a href="signin">Login</a></li>
			<li><a href="">Logout</a></li>
			<li><a href="">Admin</a></li>
			<li><a href="hello">Hello Customer</a></li>
			<li><i class="fas fa-shopping-cart"></i><a href=""> Shopping Cart</a></li>
			<li><i class="fa fa-user"></i><a href=""> User Account</a></li>
		</ul>
	</nav>
</div>
